import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public dataService : DataService) { }
  Items:any
  item1:any
  data:string=''
  ngOnInit(): void {
    this.dataService.GetAllBooks().subscribe((res)=>{
      this.item1=res;
    })

  }

  onSubmit(data1:any){
    this.dataService.SearchBook(data1).subscribe((Response)=>{
      this.item1=Response ;
       console.log(this.Items);
       console.log(data1);
    })
  }

}
