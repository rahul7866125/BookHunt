import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { DataService } from 'src/app/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

 public alertClassName="";
 public  userModel=new User();
 public message="";

  constructor(public dataService:DataService, public route:Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    this.dataService.LogIn(this.userModel).subscribe((response)=>{
      
      if(response){
        console.log("Success");
         this.message="Logged in successfully";
         this.alertClassName="alert-success";
         this.route.navigateByUrl('/dashboard');
      }

      else{
        console.log("Failed");
        this.message="User does not exist! Please register";
        this.alertClassName="alert-danger";
      }
    })
  }
}
