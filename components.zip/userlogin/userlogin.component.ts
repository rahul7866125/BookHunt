import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/login';
import { DataService } from 'src/app/data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

 public item :any 
 public alertClassName="";
 public  userModel=new Login();
 public message="";
  constructor(public dataService:DataService, public route:Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    this.dataService.LogIn(this.userModel).subscribe((response)=>{
      
      if(response==1){
        console.log("Success");
         this.message="Logged in successfully";
         this.alertClassName="alert-success";
         this.route.navigateByUrl('/home');
      }

      else{
        console.log("Failed");
        this.message="User does not exist! Please register";
        this.alertClassName="alert-danger";
      }
    })
  }

}
