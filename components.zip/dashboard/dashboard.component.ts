import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  Items:any
  data:string=''
  constructor(public dataService:DataService) { }

  ngOnInit(): void {
    this.dataService.GetAllBooks().subscribe((res)=>{
      this.Items=res;
    })
}



  onSubmit(data:any){
    this.dataService.SearchCategory(data).subscribe((Response)=>{
     this.Items=Response;
    })
  }
}
