import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(public dataService : DataService) { }
  Item:any
  data:string=''
  ngOnInit(): void {

  }

  onSubmit(data1:any){
    this.dataService.SearchBook(data1).subscribe((Response)=>{
      this.Item=Response ;
       console.log(this.Item);
       console.log(data1);
    })
  }

}
