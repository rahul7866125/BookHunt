import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

 public alertClassName="alert-success";
 public  userModel=new User();
 public message="";
  constructor(public dataService :DataService) { }

  ngOnInit(): void {
  }

  onSubmit(){
      this.dataService.Register(this.userModel).subscribe();
       this.message="Wow! Register Successfully";
  }
}
