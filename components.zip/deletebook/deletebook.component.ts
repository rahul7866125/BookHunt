import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletebook',
  templateUrl: './deletebook.component.html',
  styleUrls: ['./deletebook.component.css']
})
export class DeletebookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
